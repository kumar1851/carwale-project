
    let carsList = [
      {
        id:1,
        protuctName:"Hyundai Exter",
        rating:"238 Ratings|Rate & Win",
        image:"./image/car-2.jpeg",
        price:"Rs. 7.06 - 12.35 Lakh",
        emi:"EMI Rs. 11,471  For 5 Years",
        weeks:"Waiting Period: 14-34 Weeks",
        protuctPes:"Hyundai Exter Price",
        para:"Hyundai Exter price for the base model starts at Rs. 7.06 Lakh and the top model price goes upto Rs. 12.35 Lakh (on-road Chennai). Exter price for 17 variants is listed below.",
        FuelType:"Filter By Fuel type & Transmission",
        fuelTypes: ["Petrol","CNG","Manual","Automatic (AMT)"],
        fuelNames: ["Versions", "On-Road Price"],
        starIcon: "<i class='fa-solid fa-star'></i> <i class='fa-solid fa-star'></i> <i class='fa-solid fa-star'></i> <i class='fa-solid fa-star'></i>",
        versionsOn:[
            {title:"Exter EX 1.2 MT",paras:"1197 cc, Petrol, Manual, 19.4 kmpl, 82 bhp",
            RoadPrice:"Rs. 7.06 Lakh"},
            {title:"Exter EX (O) 1.2 MT",paras:"1197 cc, Petrol, Manual, 19.4 kmpl, 82 bhp ",
            RoadPrice:"Rs. 7.35 Lakh"},
            {title:"Exter S 1.2 MT",paras:"1197 cc, Petrol, Manual, 19.4 kmpl ",
            RoadPrice:"Rs. 8.51 Lakh"},
            {title:"Exter S (O) 1.2 MT",paras:"1197 cc, Petrol, Manual, 19.4 kmpl, 82 bhp",
            RoadPrice:"Rs. 8.68 Lakh"},
            {title:"Exter S 1.2 AMT",paras:"1197 cc, Petrol, Automatic (AMT), 19.2 kmpl, 82 bhp  ",
            RoadPrice:"Rs. 9.31 Lakh"},
        ],
        para1:"Hyundai Exter Car Specifications",
        carSpecifications:[
          {amount:"Rs. 7.06 Lakh onwards",mileage:"19.2 to 27.1 kmpl",enginer:"1197cc",fule:"Petrol & CNG",Transmission:"Manual & Automatic",Seating:"5 Seater"}
        ],
      
    
    },
    {
        id:2,
        protuctName:"Toyota Rumion",
        rating:"19 Ratings|Rate & Win",
        image:"./image/car-3.jpeg",
        price:"Rs. 12.57 - 16.63 Lakh",
        emi:"EMI Rs. 19,676 For 5 Years",
        weeks:"",
        protuctPes:"Toyota Rumion Price",
        para:"Toyota Rumion price for the base model starts at Rs. 12.57 Lakh and the top model price goes upto Rs. 16.63 Lakh (on-road Chennai). Rumion price for 6 variants is listed below.",
        FuelType:"Filter By Fuel type & Transmission",
        fuelTypes: ["Petrol","CNG","Manual","Automatic (Tc)"],
        fuelNames: ["Versions", "On-Road Price"],
        starIcon: "<i class='fa-solid fa-star'></i> <i class='fa-solid fa-star'></i> <i class='fa-solid fa-star'></i> <i class='fa-solid fa-star'></i>",
         versionsOn:[
            {title:"Rumion S MT",paras:"1462 cc, Petrol, Manual, 20.51 kmpl",
            RoadPrice:"Rs. 12.57 Lakh",},
            {title:"Rumion S CNG",paras:"1462 cc, CNG, Manual, 26.11 km/kg, 87 bhp  ",
            RoadPrice:"Rs. 13.71 Lakh"},
            {title:"Rumion G MT",paras:"1462 cc, Petrol, Manual, 20.51 kmpl, 102 bhp ",
            RoadPrice:"Rs. 13.96 Lakh"},
            {title:"Rumion S AT ",paras:"1462 cc, Petrol, Automatic (TC), 20.",
            RoadPrice:"Rs. 14.49 Lakh"},
            {title:"Rumion V MT",paras:"1462 cc, Petrol, Manual, 20.51 kmp  ",
            RoadPrice:"Rs. 14.83 Lakh"},
           ],
           para1:"Toyota Rumion Car Specifications",
           carSpecifications:[
          {amount:"Rs. 12.57 Lakh onwards",mileage:"20.11 to 26.11 kmpl",enginer:"1462 cc",fule:"Petrol & CNG",Transmission:"Manual & Automatic",Seating:"7 Seater"}
        ],
        },
        {
            id:3,
            protuctName:"Maruti Fronx",
            rating:"194 Ratings |Rate & Win",
            image:"./image/car-1.jpeg",
            price:"Rs. 8.59 - 15.66 Lakh",
            emi:"EMI Rs. 14,274 For 5 Years",
            weeks:"Waiting Period: 1-10 Weeks",
            protuctPes:"Maruti Fronx Price",
            para:"Maruti Fronx price for the base model starts at Rs. 8.59 Lakh and the top model price goes upto Rs. 15.66 Lakh (on-road Chennai). Fronx price for 14 variants is listed below.",
            FuelType:"Filter By Fuel type & Transmission",
            fuelTypes: ["Petrol","CNG","Manual","Automatic (Tc)"],
            fuelNames: ["Versions", "On-Road Price"],
            starIcon: "<i class='fa-solid fa-star'></i> <i class='fa-solid fa-star'></i> <i class='fa-solid fa-star'></i> <i class='fa-solid fa-star'></i>",
             versionsOn:[
                {title:"Fronx Sigma 1.2L MT",paras:"1197 cc, Petrol, Manual, 21.79 km",
                RoadPrice:"Rs. 8.59 Lakh",},
                {title:"Fronx Delta 1.2L MT",paras:" 1197 cc, Petrol, Manual, 21.79 kmpl, 89 bhp",
                RoadPrice:"Rs. 9.54 Lakh"},
                {title:"Fronx Sigma 1.2 CNG",paras:"1197 cc, Petrol, Manual, 28.51 kmpl, 76 bhp  ",
                RoadPrice:"Rs. 9.82 Lakh"},
                {title:"Fronx Delta Plus 1.2L MT ",paras:"1197 cc, Petrol, Manual, 21.79 kmpl, 89 bhp ",
                RoadPrice:"Rs. 9.99 Lakh"},
                {title:"Fronx Delta 1.2L AGS",paras:" 1197 cc, Petrol, Automatic (AMT), ",
                RoadPrice:"Rs. 10.16 Lakh"},
               ],
               para1:"Maruti Fronx Car Specifications",
               carSpecifications:[
              {amount:"Rs. 8.59 Lakh onwards",mileage:"20.01 to 24.48 kmpl",enginer:"998 to 1197 cc",fule:"Petrol",Transmission:"Manual & Automatic",Seating:"5 Seater"}
            ],
            
        },

]
    
let cars=document.getElementById("hyundai");

let urls = new URLSearchParams(window.location.search);

let urlRes = urls.get('id');

let checkFun = carsList.map(function(item){
    if(urlRes == item.id){
        let carsItem = 
        `<div class="container">
            <div class="hyun-title">
                <h3>${item.protuctName} </h3>
                <span>${item.starIcon}</span>
                <span class="star">${item.rating}</span>
            </div>
        </div>

        <section class="Exter_price">
            <div class="container">
                <div class="main">
                <div class="row">
                    <div class="col-lg-6 col-md-6 col-sm-12">
                         <div class="price_image">
                            <img src=${item.image} alt="">
                         </div>
                         <div class="price-row">
                            <div class="cols">
                                <span class="color_card"><i class='bx bx-palette'></i> Colour</span>
                            </div>
                            <div class="cols">
                                <span class="color_card"><i class='bx bx-image'></i>lmage</span>
                            </div>
                            <div class="cols">
                                <span class="color_card"><i class='bx bxs-videos'></i> Videos</span>
                            </div>
                         </div>
                    </div>
                    <div class="col-lg-6 col-md-6 col-sm-12">
                        <div class="city">
                            <div class="version">
                                <p>Version</p>
                                <h6>Select Version</h6>
                            </div>
                            <div class="version">
                                <p>city</p>
                                <h6>Chennai</h6>
                            </div> 
                        </div>
                         <h4>${item.price} <a href="" class="view">View Price Breakup</a> </h4>
                         <p>On-Road Price, Chennai</p>
                         <div class="city gets">
                            <div class="emi">
                                <p>${item.emi}</p>
                                    <a href="" class="view" > EMI Calculator</a>
                            </div>
                            <div class="emi">
                                <button class="button">Get EMI Offers</button>
                               </div>
                         </div>
                         <div class="weeks">
                            <span><i class='bx bx-time-five'></i></i>${item.weeks}/span>
                         </div>
                          <button class="offers">Get September Offers</button>
                          </div>
                </div>
                </div>
            </div>
          </section>
          <div class="exter-price">
            <div class="container">
                <div class="row">
                    <div class="col-lg-8">
                        <div class="card-prices">
                            <h4>${item.protuctPes}</h4>
                            <p>${item.para}</p>
                            <span  class="price_icon"><i class='bx bx-filter-alt'></i>Filter By Fuel type & Transmission</span>
                        </div>
                        <div class="card_prices ">
                          <a href=""class="fuel">  Petrol</a>  
                          <a href=""class="fuel"> CNG</a>  
                          <a href=""class="fuel">  Manual</a>  
                          <a href=""class="fuel">  Automatic (AMT)</a>  
                           </div>
                          <table class="table">
                            <thead>
                              <tr>
                                <th scope="col-sm-12" class="ver_para">Versions</th>
                                <th scope="col-sm-12" class="ver_para">On-Road Price</th>
                                <th scope="col-sm-12" class="ver_para">Compare</th>
                              </tr>
                            </thead>
                            <tbody>
                              
                                ${item.versionsOn.map(item => { 
                                    return `<tr >
                                            <td>
                                                <a href="" class="peterol-cc">${item.title}</a>
                                                <p>${item.paras}</p>
                                            </td>
                                            <td>${item.RoadPrice}</td>
                                             <td><h6 class="view-get">View Price BreakupGet Offers</h6></td>
                                        </tr>`
                                }).join('')}
                            </tbody>

                          </table> 
                           <div class="exter-car">
                                <h4>${item.para1}</h4>
                                <table class="table">
                                  <thead>
                                    
                                  </thead>
                                  <tbody>
                                  ${item.carSpecifications.map(item =>{
                                    return `<tr>
                                    <td><img src="image/money-banking.png" alt="" class="laal">Price
                                            <p class="rs">${item.amount}</p></td>
                                            <td><img src="image/performance.png" alt="" class="laal"></i>Mileage
                                                 <p class="rs"> ${item.mileage} </p></td>
                                                 <td><img src="image/car-engine.png" alt="" class="laal">Engine
                                                 <p class="rs"> ${item.enginer} </td>
                                            </tr> 
                                            <tr>
                                            <td><img src="image/fuel-station.png" alt="" class="laal">Fuel Type
                                              <p class="rs">${item.fule}</p></td>
                                              <td><img src="image/manual-transmission.png" alt="" class="laal">Transmission
                                                <p class="rs">${item.Transmission}</p></td>
                                                <td><img src="image/seat.png" alt="" class="laal">Seating Capacity
                                                  <p class="rs"> ${item.Seating}</p></td>
                                           </tr>`
                                            
                                  })}
                                    
                                  
                                  </tbody>
                                </table>
                              </div>
                               </div>
                         <div class="col-lg-4">
                    <div class="carblue">
                        <img src="image/blue-1.jpeg" alt="">
                    </div>
                    <div class="carblue">
                      <img src="image/blue-2.jpeg" alt="">
                  </div>
                  <div class="carblue">
                    <img src="image/blue-3.gif" alt="">
                </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        
        `
        cars.innerHTML = carsItem;
        console.log("success")

    }
    else{
        console.log("err")
    }
})

    
   
    
    

